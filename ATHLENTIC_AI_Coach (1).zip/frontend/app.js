
async function startCoach() {
  const response = await fetch('http://localhost:3000/api/coach', { method: 'POST' });
  const data = await response.json();
  document.getElementById('output').innerText = data.message;
}
