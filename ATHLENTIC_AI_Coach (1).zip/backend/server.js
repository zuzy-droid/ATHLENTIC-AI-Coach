
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const configuration = new Configuration({
  apiKey: 'YOUR_OPENAI_API_KEY_HERE',
});
const openai = new OpenAIApi(configuration);

app.post('/api/coach', async (req, res) => {
  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: 'You are an AI coach for athletes focusing on mindset and physical readiness.' },
        { role: 'user', content: 'Give me a daily mental and physical challenge for an athlete.' }
      ],
    });
    res.json({ message: completion.data.choices[0].message.content });
  } catch (error) {
    res.status(500).send('AI error');
  }
});

app.listen(3000, () => {
  console.log('ATHLENTIC AI Coach server running on port 3000');
});
